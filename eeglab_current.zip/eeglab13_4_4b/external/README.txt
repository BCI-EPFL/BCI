This folder use to contain modules external to EEGLAB
Now all external modules are treated as EEGLAB extensions
and this folder is not longer needed.

This folder will be removed in subsequent EEGLAB releases.

A. Delorme - Nov 30, 2013
